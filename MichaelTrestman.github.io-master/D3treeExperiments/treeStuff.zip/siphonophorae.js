var siphData = {
   
   "nodes": [
      {
         "group": 1, 
         "name": "Siphonophorae", 
         "itis_id": 718928, 
         "year": 1758
      }, 
      {
         "group": 1, 
         "name": "Physonectae", 
         "itis_id": 718936, 
         "year": 1775
      }, 
      {
         "group": 1, 
         "name": "Pyrostephidae", 
         "itis_id": 718957, 
         "year": 1954
      }, 
      {
         "group": 1, 
         "name": "Bargmannia", 
         "itis_id": 51385, 
         "year": 1954
      }, 
      {
         "group": 1, 
         "name": "Bargmannia lata", 
         "itis_id": 719189, 
         "year": 1998
      }, 
      {
         "group": 1, 
         "name": "Bargmannia amoena", 
         "itis_id": 719188, 
         "year": 1999
      }, 
      {
         "group": 1, 
         "name": "Bargmannia elongata", 
         "itis_id": 51386, 
         "year": 1954
      }, 
      {
         "group": 1, 
         "name": "Agalmatidae", 
         "itis_id": 718956, 
         "year": 1807
      }, 
      {
         "group": 1, 
         "name": "Lychnagalma", 
         "itis_id": 719007, 
         "year": 1879
      }, 
      {
         "group": 1, 
         "name": "Lychnagalma utricularia", 
         "itis_id": 719187, 
         "year": 1879
      }, 
      {
         "group": 1, 
         "name": "Frillagalma", 
         "itis_id": 719006, 
         "year": 1966
      }, 
      {
         "group": 1, 
         "name": "Frillagalma vityazi", 
         "itis_id": 719183, 
         "year": 1966
      }, 
      {
         "group": 1, 
         "name": "Halistemma", 
         "itis_id": 51397, 
         "year": 1807
      }, 
      {
         "group": 1, 
         "name": "Halistemma transliratum", 
         "itis_id": 719186, 
         "year": 1988
      }, 
      {
         "group": 1, 
         "name": "Halistemma striata", 
         "itis_id": 719185, 
         "year": 1965
      }, 
      {
         "group": 1, 
         "name": "Halistemma cupulifera", 
         "itis_id": 719184, 
         "year": 1908
      }, 
      {
         "group": 1, 
         "name": "Halistemma rubrum", 
         "itis_id": 51400, 
         "year": 1852
      }, 
      {
         "group": 1, 
         "name": "Halistemma amphytridis", 
         "itis_id": 51398, 
         "year": 1807
      }, 
      {
         "group": 1, 
         "name": "Erenna", 
         "itis_id": 51395, 
         "year": 1904
      }, 
      {
         "group": 1, 
         "name": "Erenna richardi", 
         "itis_id": 51396, 
         "year": 1904
      }, 
      {
         "group": 1, 
         "name": "Cordagalma", 
         "itis_id": 51393, 
         "year": 1932
      }, 
      {
         "group": 1, 
         "name": "Cordagalma cordiforme", 
         "itis_id": 51394, 
         "year": 1932
      }, 
      {
         "group": 1, 
         "name": "Marrus", 
         "itis_id": 51390, 
         "year": 1942
      }, 
      {
         "group": 1, 
         "name": "Marrus orthocanna", 
         "itis_id": 51392, 
         "year": 1942
      }, 
      {
         "group": 1, 
         "name": "Marrus antarcticus", 
         "itis_id": 51391, 
         "year": 1954
      }, 
      {
         "group": 1, 
         "name": "Nanomia", 
         "itis_id": 51387, 
         "year": 1841
      }, 
      {
         "group": 1, 
         "name": "Nanomia bijuga", 
         "itis_id": 51389, 
         "year": 1841
      }, 
      {
         "group": 1, 
         "name": "Nanomia cara", 
         "itis_id": 51388, 
         "year": 1865
      }, 
      {
         "group": 1, 
         "name": "Agalma", 
         "itis_id": 51382, 
         "year": 1825
      }, 
      {
         "group": 1, 
         "name": "Agalma okeni", 
         "itis_id": 51384, 
         "year": 1825
      }, 
      {
         "group": 1, 
         "name": "Agalma elegans", 
         "itis_id": 51383, 
         "year": 1846
      }, 
      {
         "group": 1, 
         "name": "Apolemiidae", 
         "itis_id": 718955, 
         "year": 1815
      }, 
      {
         "group": 1, 
         "name": "Ramosia", 
         "itis_id": 51423, 
         "year": 1967
      }, 
      {
         "group": 1, 
         "name": "Ramosia vitiazi", 
         "itis_id": 51424, 
         "year": 1967
      }, 
      {
         "group": 1, 
         "name": "Apolemia", 
         "itis_id": 51421, 
         "year": 1815
      }, 
      {
         "group": 1, 
         "name": "Apolemia uvaria", 
         "itis_id": 51422, 
         "year": 1815
      }, 
      {
         "group": 1, 
         "name": "Athorybiidae", 
         "itis_id": 51425, 
         "year": 1775
      }, 
      {
         "group": 1, 
         "name": "Athorybia", 
         "itis_id": 51426, 
         "year": 1775
      }, 
      {
         "group": 1, 
         "name": "Athorybia rosacea", 
         "itis_id": 51428, 
         "year": 1775
      }, 
      {
         "group": 1, 
         "name": "Athorybia lucida", 
         "itis_id": 51427, 
         "year": 1978
      }, 
      {
         "group": 1, 
         "name": "Forskaliidae", 
         "itis_id": 51416, 
         "year": 1853
      }, 
      {
         "group": 1, 
         "name": "Forskalia", 
         "itis_id": 51417, 
         "year": 1853
      }, 
      {
         "group": 1, 
         "name": "Forskalia tholoides", 
         "itis_id": 51419, 
         "year": 1888
      }, 
      {
         "group": 1, 
         "name": "Forskalia edwardsi", 
         "itis_id": 51418, 
         "year": 1853
      }, 
      {
         "group": 1, 
         "name": "Rhodaliidae", 
         "itis_id": 51409, 
         "year": 1886
      }, 
      {
         "group": 1, 
         "name": "Stephalia", 
         "itis_id": 51414, 
         "year": 1888
      }, 
      {
         "group": 1, 
         "name": "Stephalia bathyphysa", 
         "itis_id": 51415, 
         "year": 1888
      }, 
      {
         "group": 1, 
         "name": "Angelopsis", 
         "itis_id": 51412, 
         "year": 1886
      }, 
      {
         "group": 1, 
         "name": "Angelopsis globosa", 
         "itis_id": 51413, 
         "year": 1886
      }, 
      {
         "group": 1, 
         "name": "Dromalia", 
         "itis_id": 51410, 
         "year": 1911
      }, 
      {
         "group": 1, 
         "name": "Dromalia alexandri", 
         "itis_id": 51411, 
         "year": 1911
      }, 
      {
         "group": 1, 
         "name": "Physophoridae", 
         "itis_id": 51405, 
         "year": 1775
      }, 
      {
         "group": 1, 
         "name": "Physophora", 
         "itis_id": 51406, 
         "year": 1775
      }, 
      {
         "group": 1, 
         "name": "Physophora hydrostatica", 
         "itis_id": 51407, 
         "year": 1775
      }, 
      {
         "group": 1, 
         "name": "Stephanomia", 
         "itis_id": 51403, 
         "year": 1834
      }, 
      {
         "group": 1, 
         "name": "Stephanomia imbricata", 
         "itis_id": 51404, 
         "year": 1834
      }, 
      {
         "group": 1, 
         "name": "Cystonectae", 
         "itis_id": 718935, 
         "year": 1758
      }, 
      {
         "group": 1, 
         "name": "Physaliidae", 
         "itis_id": 51434, 
         "year": 1758
      }, 
      {
         "group": 1, 
         "name": "Physalia", 
         "itis_id": 51435, 
         "year": 1758
      }, 
      {
         "group": 1, 
         "name": "Physalia physalis", 
         "itis_id": 719181, 
         "year": 1758
      }, 
      {
         "group": 1, 
         "name": "Rhizophysidae", 
         "itis_id": 51430, 
         "year": 1775
      }, 
      {
         "group": 1, 
         "name": "Bathyphysa", 
         "itis_id": 719005, 
         "year": 1878
      }, 
      {
         "group": 1, 
         "name": "Bathyphysa conifera", 
         "itis_id": 719182, 
         "year": 1878
      }, 
      {
         "group": 1, 
         "name": "Rhizophysa", 
         "itis_id": 51431, 
         "year": 1775
      }, 
      {
         "group": 1, 
         "name": "Rhizophysa filiformis", 
         "itis_id": 51433, 
         "year": 1775
      }, 
      {
         "group": 1, 
         "name": "Rhizophysa eysenhardti", 
         "itis_id": 51432, 
         "year": 1859
      }, 
      {
         "group": 1, 
         "name": "Calycophorae", 
         "itis_id": 51269, 
         "year": 1776
      }, 
      {
         "group": 1, 
         "name": "Clausophyidae", 
         "itis_id": 718958, 
         "year": 1860
      }, 
      {
         "group": 1, 
         "name": "Heteropyramis", 
         "itis_id": 51322, 
         "year": 1925
      }, 
      {
         "group": 1, 
         "name": "Heteropyramis maculata", 
         "itis_id": 51323, 
         "year": 1925
      }, 
      {
         "group": 1, 
         "name": "Crystallophyes", 
         "itis_id": 51320, 
         "year": 1925
      }, 
      {
         "group": 1, 
         "name": "Crystallophyes amygdalina", 
         "itis_id": 51321, 
         "year": 1925
      }, 
      {
         "group": 1, 
         "name": "Chuniphyes", 
         "itis_id": 51303, 
         "year": 1908
      }, 
      {
         "group": 1, 
         "name": "Chuniphyes moserae", 
         "itis_id": 51305, 
         "year": 1954
      }, 
      {
         "group": 1, 
         "name": "Chuniphyes multidentata", 
         "itis_id": 51304, 
         "year": 1908
      }, 
      {
         "group": 1, 
         "name": "Clausophyes", 
         "itis_id": 51274, 
         "year": 1860
      }, 
      {
         "group": 1, 
         "name": "Clausophyes moserae", 
         "itis_id": 719201, 
         "year": 1988
      }, 
      {
         "group": 1, 
         "name": "Clausophyes ovata", 
         "itis_id": 51276, 
         "year": 1860
      }, 
      {
         "group": 1, 
         "name": "Clausophyes galeata", 
         "itis_id": 51275, 
         "year": 1908
      }, 
      {
         "group": 1, 
         "name": "Abylidae", 
         "itis_id": 51362, 
         "year": 1823
      }, 
      {
         "group": 1, 
         "name": "Ceratocymba", 
         "itis_id": 51375, 
         "year": 1827
      }, 
      {
         "group": 1, 
         "name": "Ceratocymba dentata", 
         "itis_id": 51379, 
         "year": 1918
      }, 
      {
         "group": 1, 
         "name": "Ceratocymba intermedia", 
         "itis_id": 51378, 
         "year": 1953
      }, 
      {
         "group": 1, 
         "name": "Ceratocymba sagittata", 
         "itis_id": 51377, 
         "year": 1827
      }, 
      {
         "group": 1, 
         "name": "Ceratocymba leuckarti", 
         "itis_id": 51376, 
         "year": 1859
      }, 
      {
         "group": 1, 
         "name": "Abylopsis", 
         "itis_id": 51369, 
         "year": 1823
      }, 
      {
         "group": 1, 
         "name": "Abylopsis bicarinata", 
         "itis_id": 51374, 
         "year": 1925
      }, 
      {
         "group": 1, 
         "name": "Abylopsis haeckeli", 
         "itis_id": 51373, 
         "year": 1908
      }, 
      {
         "group": 1, 
         "name": "Abylopsis trigona", 
         "itis_id": 51372, 
         "year": 1827
      }, 
      {
         "group": 1, 
         "name": "Abylopsis eschscholtzi", 
         "itis_id": 51371, 
         "year": 1859
      }, 
      {
         "group": 1, 
         "name": "Abylopsis tetragona", 
         "itis_id": 51370, 
         "year": 1823
      }, 
      {
         "group": 1, 
         "name": "Abyla", 
         "itis_id": 51365, 
         "year": 1827
      }, 
      {
         "group": 1, 
         "name": "Abyla bicarinata", 
         "itis_id": 51368, 
         "year": 1925
      }, 
      {
         "group": 1, 
         "name": "Abyla haeckeli", 
         "itis_id": 51367, 
         "year": 1908
      }, 
      {
         "group": 1, 
         "name": "Abyla trigona", 
         "itis_id": 51366, 
         "year": 1827
      }, 
      {
         "group": 1, 
         "name": "Enneagonum", 
         "itis_id": 51363, 
         "year": 1827
      }, 
      {
         "group": 1, 
         "name": "Enneagonum hyalinum", 
         "itis_id": 51364, 
         "year": 1827
      }, 
      {
         "group": 1, 
         "name": "Bassia", 
         "itis_id": 51357, 
         "year": 1833
      }, 
      {
         "group": 1, 
         "name": "Bassia bassensis", 
         "itis_id": 51359, 
         "year": 1833
      }, 
      {
         "group": 1, 
         "name": "Sphaeronectidae", 
         "itis_id": 51356, 
         "year": 1873
      }, 
      {
         "group": 1, 
         "name": "Sphaeronectes", 
         "itis_id": 51360, 
         "year": 1873
      }, 
      {
         "group": 1, 
         "name": "Sphaeronectes irregularis", 
         "itis_id": 719202, 
         "year": 1873
      }, 
      {
         "group": 1, 
         "name": "Sphaeronectes gracilis", 
         "itis_id": 51361, 
         "year": 1873
      }, 
      {
         "group": 1, 
         "name": "Prayidae", 
         "itis_id": 51332, 
         "year": 1822
      }, 
      {
         "group": 1, 
         "name": "Prayola", 
         "itis_id": 719012, 
         "year": 1987
      }, 
      {
         "group": 1, 
         "name": "Prayola urinatrix", 
         "itis_id": 719195, 
         "year": 1987
      }, 
      {
         "group": 1, 
         "name": "Nectadamas", 
         "itis_id": 719011, 
         "year": 1911
      }, 
      {
         "group": 1, 
         "name": "Nectadamas diomedeae", 
         "itis_id": 719194, 
         "year": 1911
      }, 
      {
         "group": 1, 
         "name": "Mistoprayina", 
         "itis_id": 719010, 
         "year": 1987
      }, 
      {
         "group": 1, 
         "name": "Mistoprayina fragosa", 
         "itis_id": 719193, 
         "year": 1987
      }, 
      {
         "group": 1, 
         "name": "Maresearsia", 
         "itis_id": 719009, 
         "year": 1954
      }, 
      {
         "group": 1, 
         "name": "Maresearsia praeclara", 
         "itis_id": 719192, 
         "year": 1954
      }, 
      {
         "group": 1, 
         "name": "Craseoa", 
         "itis_id": 719008, 
         "year": 1987
      }, 
      {
         "group": 1, 
         "name": "Craseoa lathetica", 
         "itis_id": 719190, 
         "year": 1987
      }, 
      {
         "group": 1, 
         "name": "Desmailia", 
         "itis_id": 51354, 
         "year": 1888
      }, 
      {
         "group": 1, 
         "name": "Desmailia imbricata", 
         "itis_id": 51355, 
         "year": 1888
      }, 
      {
         "group": 1, 
         "name": "Stephanophyes", 
         "itis_id": 51352, 
         "year": 1888
      }, 
      {
         "group": 1, 
         "name": "Stephanophyes superba", 
         "itis_id": 51353, 
         "year": 1888
      }, 
      {
         "group": 1, 
         "name": "Lilyopsis", 
         "itis_id": 51350, 
         "year": 1885
      }, 
      {
         "group": 1, 
         "name": "Lilyopsis rosea", 
         "itis_id": 51351, 
         "year": 1885
      }, 
      {
         "group": 1, 
         "name": "Desmophyes", 
         "itis_id": 51348, 
         "year": 1888
      }, 
      {
         "group": 1, 
         "name": "Desmophyes haematogaster", 
         "itis_id": 719191, 
         "year": 1992
      }, 
      {
         "group": 1, 
         "name": "Desmophyes annectens", 
         "itis_id": 51349, 
         "year": 1888
      }, 
      {
         "group": 1, 
         "name": "Amphicaryon", 
         "itis_id": 51345, 
         "year": 1888
      }, 
      {
         "group": 1, 
         "name": "Amphicaryon ernesti", 
         "itis_id": 51347, 
         "year": 1954
      }, 
      {
         "group": 1, 
         "name": "Amphicaryon acaule", 
         "itis_id": 51346, 
         "year": 1888
      }, 
      {
         "group": 1, 
         "name": "Rosacea", 
         "itis_id": 51340, 
         "year": 1822
      }, 
      {
         "group": 1, 
         "name": "Rosacea repanda", 
         "itis_id": 719197, 
         "year": 1988
      }, 
      {
         "group": 1, 
         "name": "Rosacea limbata", 
         "itis_id": 719196, 
         "year": 1988
      }, 
      {
         "group": 1, 
         "name": "Rosacea flaccida", 
         "itis_id": 51344, 
         "year": 1978
      }, 
      {
         "group": 1, 
         "name": "Rosacea cymbiformis", 
         "itis_id": 51343, 
         "year": 1822
      }, 
      {
         "group": 1, 
         "name": "Rosacea plicata", 
         "itis_id": 51341, 
         "year": 1827
      }, 
      {
         "group": 1, 
         "name": "Praya", 
         "itis_id": 51337, 
         "year": 1827
      }, 
      {
         "group": 1, 
         "name": "Praya dubia", 
         "itis_id": 51339, 
         "year": 1827
      }, 
      {
         "group": 1, 
         "name": "Praya reticulata", 
         "itis_id": 51338, 
         "year": 1911
      }, 
      {
         "group": 1, 
         "name": "Nectopyramis", 
         "itis_id": 51333, 
         "year": 1911
      }, 
      {
         "group": 1, 
         "name": "Nectopyramis thetis", 
         "itis_id": 51336, 
         "year": 1911
      }, 
      {
         "group": 1, 
         "name": "Nectopyramis natans", 
         "itis_id": 51335, 
         "year": 1911
      }, 
      {
         "group": 1, 
         "name": "Hippopodiidae", 
         "itis_id": 51324, 
         "year": 1776
      }, 
      {
         "group": 1, 
         "name": "Hippopodius", 
         "itis_id": 51330, 
         "year": 1776
      }, 
      {
         "group": 1, 
         "name": "Hippopodius hippopus", 
         "itis_id": 51331, 
         "year": 1776
      }, 
      {
         "group": 1, 
         "name": "Vogtia", 
         "itis_id": 51325, 
         "year": 1853
      }, 
      {
         "group": 1, 
         "name": "Vogtia spinosa", 
         "itis_id": 51329, 
         "year": 1861
      }, 
      {
         "group": 1, 
         "name": "Vogtia pentacantha", 
         "itis_id": 51328, 
         "year": 1853
      }, 
      {
         "group": 1, 
         "name": "Vogtia glabra", 
         "itis_id": 51327, 
         "year": 1918
      }, 
      {
         "group": 1, 
         "name": "Vogtia serrata", 
         "itis_id": 51326, 
         "year": 1925
      }, 
      {
         "group": 1, 
         "name": "Diphyidae", 
         "itis_id": 51270, 
         "year": 1821
      }, 
      {
         "group": 1, 
         "name": "Gilia", 
         "itis_id": 719013, 
         "year": 1954
      }, 
      {
         "group": 1, 
         "name": "Gilia reticulata", 
         "itis_id": 719198, 
         "year": 1954
      }, 
      {
         "group": 1, 
         "name": "Sulculeolaria", 
         "itis_id": 51314, 
         "year": 1834
      }, 
      {
         "group": 1, 
         "name": "Sulculeolaria turgida", 
         "itis_id": 51319, 
         "year": 1853
      }, 
      {
         "group": 1, 
         "name": "Sulculeolaria monoica", 
         "itis_id": 51318, 
         "year": 1888
      }, 
      {
         "group": 1, 
         "name": "Sulculeolaria biloba", 
         "itis_id": 51317, 
         "year": 1846
      }, 
      {
         "group": 1, 
         "name": "Sulculeolaria quadrivalvis", 
         "itis_id": 51316, 
         "year": 1834
      }, 
      {
         "group": 1, 
         "name": "Sulculeolaria chuni", 
         "itis_id": 51315, 
         "year": 1908
      }, 
      {
         "group": 1, 
         "name": "Eudoxoides", 
         "itis_id": 51311, 
         "year": 1859
      }, 
      {
         "group": 1, 
         "name": "Eudoxoides mitra", 
         "itis_id": 51313, 
         "year": 1859
      }, 
      {
         "group": 1, 
         "name": "Eudoxoides spiralis", 
         "itis_id": 51312, 
         "year": 1911
      }, 
      {
         "group": 1, 
         "name": "Diphyes", 
         "itis_id": 51306, 
         "year": 1821
      }, 
      {
         "group": 1, 
         "name": "Diphyes antarctica", 
         "itis_id": 719259, 
         "year": 1925
      }, 
      {
         "group": 1, 
         "name": "Diphyes chamissonis", 
         "itis_id": 51310, 
         "year": 1859
      }, 
      {
         "group": 1, 
         "name": "Diphyes bojani", 
         "itis_id": 51309, 
         "year": 1829
      }, 
      {
         "group": 1, 
         "name": "Diphyes dispar", 
         "itis_id": 51307, 
         "year": 1821
      }, 
      {
         "group": 1, 
         "name": "Dimophyes", 
         "itis_id": 51301, 
         "year": 1897
      }, 
      {
         "group": 1, 
         "name": "Dimophyes arctica", 
         "itis_id": 51302, 
         "year": 1897
      }, 
      {
         "group": 1, 
         "name": "Muggiaea", 
         "itis_id": 51296, 
         "year": 1844
      }, 
      {
         "group": 1, 
         "name": "Muggiaea kochi", 
         "itis_id": 51300, 
         "year": 1844
      }, 
      {
         "group": 1, 
         "name": "Muggiaea bargmannae", 
         "itis_id": 51298, 
         "year": 1954
      }, 
      {
         "group": 1, 
         "name": "Muggiaea atlantica", 
         "itis_id": 51297, 
         "year": 1892
      }, 
      {
         "group": 1, 
         "name": "Lensia", 
         "itis_id": 51277, 
         "year": 1860
      }, 
      {
         "group": 1, 
         "name": "Lensia meteori", 
         "itis_id": 719200, 
         "year": 1934
      }, 
      {
         "group": 1, 
         "name": "Lensia exeter", 
         "itis_id": 719199, 
         "year": 1941
      }, 
      {
         "group": 1, 
         "name": "Lensia lelouveteau", 
         "itis_id": 51294, 
         "year": 1941
      }, 
      {
         "group": 1, 
         "name": "Lensia hotspur", 
         "itis_id": 51293, 
         "year": 1941
      }, 
      {
         "group": 1, 
         "name": "Lensia hostile", 
         "itis_id": 51292, 
         "year": 1941
      }, 
      {
         "group": 1, 
         "name": "Lensia havock", 
         "itis_id": 51291, 
         "year": 1941
      }, 
      {
         "group": 1, 
         "name": "Lensia challengeri", 
         "itis_id": 51290, 
         "year": 1954
      }, 
      {
         "group": 1, 
         "name": "Lensia campanella", 
         "itis_id": 51289, 
         "year": 1925
      }, 
      {
         "group": 1, 
         "name": "Lensia ajax", 
         "itis_id": 51288, 
         "year": 1941
      }, 
      {
         "group": 1, 
         "name": "Lensia grimaldi", 
         "itis_id": 51287, 
         "year": 1933
      }, 
      {
         "group": 1, 
         "name": "Lensia subtiloides", 
         "itis_id": 51286, 
         "year": 1908
      }, 
      {
         "group": 1, 
         "name": "Lensia subtilis", 
         "itis_id": 51285, 
         "year": 1886
      }, 
      {
         "group": 1, 
         "name": "Lensia cossack", 
         "itis_id": 51284, 
         "year": 1941
      }, 
      {
         "group": 1, 
         "name": "Lensia fowleri", 
         "itis_id": 51283, 
         "year": 1911
      }, 
      {
         "group": 1, 
         "name": "Lensia multicristata", 
         "itis_id": 51282, 
         "year": 1925
      }, 
      {
         "group": 1, 
         "name": "Lensia conoidea", 
         "itis_id": 51280, 
         "year": 1860
      }, 
      {
         "group": 1, 
         "name": "Lensia baryi", 
         "itis_id": 51279, 
         "year": 1965
      }, 
      {
         "group": 1, 
         "name": "Lensia achilles", 
         "itis_id": 51278, 
         "year": 1941
      }, 
      {
         "group": 1, 
         "name": "Chelophyes", 
         "itis_id": 51271, 
         "year": 1829
      }, 
      {
         "group": 1, 
         "name": "Chelophyes contorta", 
         "itis_id": 51273, 
         "year": 1908
      }, 
      {
         "group": 1, 
         "name": "Chelophyes appendiculata", 
         "itis_id": 51272, 
         "year": 1829
      }
   ], 
   "links": [
      {
         "source": 0, 
         "target": 1, 
         "value": 1
      }, 
      {
         "source": 1, 
         "target": 2, 
         "value": 1
      }, 
      {
         "source": 2, 
         "target": 3, 
         "value": 1
      }, 
      {
         "source": 3, 
         "target": 4, 
         "value": 1
      }, 
      {
         "source": 3, 
         "target": 5, 
         "value": 1
      }, 
      {
         "source": 3, 
         "target": 6, 
         "value": 1
      }, 
      {
         "source": 1, 
         "target": 7, 
         "value": 1
      }, 
      {
         "source": 7, 
         "target": 8, 
         "value": 1
      }, 
      {
         "source": 8, 
         "target": 9, 
         "value": 1
      }, 
      {
         "source": 7, 
         "target": 10, 
         "value": 1
      }, 
      {
         "source": 10, 
         "target": 11, 
         "value": 1
      }, 
      {
         "source": 7, 
         "target": 12, 
         "value": 1
      }, 
      {
         "source": 12, 
         "target": 13, 
         "value": 1
      }, 
      {
         "source": 12, 
         "target": 14, 
         "value": 1
      }, 
      {
         "source": 12, 
         "target": 15, 
         "value": 1
      }, 
      {
         "source": 12, 
         "target": 16, 
         "value": 1
      }, 
      {
         "source": 12, 
         "target": 17, 
         "value": 1
      }, 
      {
         "source": 7, 
         "target": 18, 
         "value": 1
      }, 
      {
         "source": 18, 
         "target": 19, 
         "value": 1
      }, 
      {
         "source": 7, 
         "target": 20, 
         "value": 1
      }, 
      {
         "source": 20, 
         "target": 21, 
         "value": 1
      }, 
      {
         "source": 7, 
         "target": 22, 
         "value": 1
      }, 
      {
         "source": 22, 
         "target": 23, 
         "value": 1
      }, 
      {
         "source": 22, 
         "target": 24, 
         "value": 1
      }, 
      {
         "source": 7, 
         "target": 25, 
         "value": 1
      }, 
      {
         "source": 25, 
         "target": 26, 
         "value": 1
      }, 
      {
         "source": 25, 
         "target": 27, 
         "value": 1
      }, 
      {
         "source": 7, 
         "target": 28, 
         "value": 1
      }, 
      {
         "source": 28, 
         "target": 29, 
         "value": 1
      }, 
      {
         "source": 28, 
         "target": 30, 
         "value": 1
      }, 
      {
         "source": 1, 
         "target": 31, 
         "value": 1
      }, 
      {
         "source": 31, 
         "target": 32, 
         "value": 1
      }, 
      {
         "source": 32, 
         "target": 33, 
         "value": 1
      }, 
      {
         "source": 31, 
         "target": 34, 
         "value": 1
      }, 
      {
         "source": 34, 
         "target": 35, 
         "value": 1
      }, 
      {
         "source": 1, 
         "target": 36, 
         "value": 1
      }, 
      {
         "source": 36, 
         "target": 37, 
         "value": 1
      }, 
      {
         "source": 37, 
         "target": 38, 
         "value": 1
      }, 
      {
         "source": 37, 
         "target": 39, 
         "value": 1
      }, 
      {
         "source": 1, 
         "target": 40, 
         "value": 1
      }, 
      {
         "source": 40, 
         "target": 41, 
         "value": 1
      }, 
      {
         "source": 41, 
         "target": 42, 
         "value": 1
      }, 
      {
         "source": 41, 
         "target": 43, 
         "value": 1
      }, 
      {
         "source": 1, 
         "target": 44, 
         "value": 1
      }, 
      {
         "source": 44, 
         "target": 45, 
         "value": 1
      }, 
      {
         "source": 45, 
         "target": 46, 
         "value": 1
      }, 
      {
         "source": 44, 
         "target": 47, 
         "value": 1
      }, 
      {
         "source": 47, 
         "target": 48, 
         "value": 1
      }, 
      {
         "source": 44, 
         "target": 49, 
         "value": 1
      }, 
      {
         "source": 49, 
         "target": 50, 
         "value": 1
      }, 
      {
         "source": 1, 
         "target": 51, 
         "value": 1
      }, 
      {
         "source": 51, 
         "target": 52, 
         "value": 1
      }, 
      {
         "source": 52, 
         "target": 53, 
         "value": 1
      }, 
      {
         "source": 1, 
         "target": 54, 
         "value": 1
      }, 
      {
         "source": 54, 
         "target": 55, 
         "value": 1
      }, 
      {
         "source": 0, 
         "target": 56, 
         "value": 1
      }, 
      {
         "source": 56, 
         "target": 57, 
         "value": 1
      }, 
      {
         "source": 57, 
         "target": 58, 
         "value": 1
      }, 
      {
         "source": 58, 
         "target": 59, 
         "value": 1
      }, 
      {
         "source": 56, 
         "target": 60, 
         "value": 1
      }, 
      {
         "source": 60, 
         "target": 61, 
         "value": 1
      }, 
      {
         "source": 61, 
         "target": 62, 
         "value": 1
      }, 
      {
         "source": 60, 
         "target": 63, 
         "value": 1
      }, 
      {
         "source": 63, 
         "target": 64, 
         "value": 1
      }, 
      {
         "source": 63, 
         "target": 65, 
         "value": 1
      }, 
      {
         "source": 0, 
         "target": 66, 
         "value": 1
      }, 
      {
         "source": 66, 
         "target": 67, 
         "value": 1
      }, 
      {
         "source": 67, 
         "target": 68, 
         "value": 1
      }, 
      {
         "source": 68, 
         "target": 69, 
         "value": 1
      }, 
      {
         "source": 67, 
         "target": 70, 
         "value": 1
      }, 
      {
         "source": 70, 
         "target": 71, 
         "value": 1
      }, 
      {
         "source": 67, 
         "target": 72, 
         "value": 1
      }, 
      {
         "source": 72, 
         "target": 73, 
         "value": 1
      }, 
      {
         "source": 72, 
         "target": 74, 
         "value": 1
      }, 
      {
         "source": 67, 
         "target": 75, 
         "value": 1
      }, 
      {
         "source": 75, 
         "target": 76, 
         "value": 1
      }, 
      {
         "source": 75, 
         "target": 77, 
         "value": 1
      }, 
      {
         "source": 75, 
         "target": 78, 
         "value": 1
      }, 
      {
         "source": 66, 
         "target": 79, 
         "value": 1
      }, 
      {
         "source": 79, 
         "target": 80, 
         "value": 1
      }, 
      {
         "source": 80, 
         "target": 81, 
         "value": 1
      }, 
      {
         "source": 80, 
         "target": 82, 
         "value": 1
      }, 
      {
         "source": 80, 
         "target": 83, 
         "value": 1
      }, 
      {
         "source": 80, 
         "target": 84, 
         "value": 1
      }, 
      {
         "source": 79, 
         "target": 85, 
         "value": 1
      }, 
      {
         "source": 85, 
         "target": 86, 
         "value": 1
      }, 
      {
         "source": 85, 
         "target": 87, 
         "value": 1
      }, 
      {
         "source": 85, 
         "target": 88, 
         "value": 1
      }, 
      {
         "source": 85, 
         "target": 89, 
         "value": 1
      }, 
      {
         "source": 85, 
         "target": 90, 
         "value": 1
      }, 
      {
         "source": 79, 
         "target": 91, 
         "value": 1
      }, 
      {
         "source": 91, 
         "target": 92, 
         "value": 1
      }, 
      {
         "source": 91, 
         "target": 93, 
         "value": 1
      }, 
      {
         "source": 91, 
         "target": 94, 
         "value": 1
      }, 
      {
         "source": 79, 
         "target": 95, 
         "value": 1
      }, 
      {
         "source": 95, 
         "target": 96, 
         "value": 1
      }, 
      {
         "source": 79, 
         "target": 97, 
         "value": 1
      }, 
      {
         "source": 97, 
         "target": 98, 
         "value": 1
      }, 
      {
         "source": 66, 
         "target": 99, 
         "value": 1
      }, 
      {
         "source": 99, 
         "target": 100, 
         "value": 1
      }, 
      {
         "source": 100, 
         "target": 101, 
         "value": 1
      }, 
      {
         "source": 100, 
         "target": 102, 
         "value": 1
      }, 
      {
         "source": 66, 
         "target": 103, 
         "value": 1
      }, 
      {
         "source": 103, 
         "target": 104, 
         "value": 1
      }, 
      {
         "source": 104, 
         "target": 105, 
         "value": 1
      }, 
      {
         "source": 103, 
         "target": 106, 
         "value": 1
      }, 
      {
         "source": 106, 
         "target": 107, 
         "value": 1
      }, 
      {
         "source": 103, 
         "target": 108, 
         "value": 1
      }, 
      {
         "source": 108, 
         "target": 109, 
         "value": 1
      }, 
      {
         "source": 103, 
         "target": 110, 
         "value": 1
      }, 
      {
         "source": 110, 
         "target": 111, 
         "value": 1
      }, 
      {
         "source": 103, 
         "target": 112, 
         "value": 1
      }, 
      {
         "source": 112, 
         "target": 113, 
         "value": 1
      }, 
      {
         "source": 103, 
         "target": 114, 
         "value": 1
      }, 
      {
         "source": 114, 
         "target": 115, 
         "value": 1
      }, 
      {
         "source": 103, 
         "target": 116, 
         "value": 1
      }, 
      {
         "source": 116, 
         "target": 117, 
         "value": 1
      }, 
      {
         "source": 103, 
         "target": 118, 
         "value": 1
      }, 
      {
         "source": 118, 
         "target": 119, 
         "value": 1
      }, 
      {
         "source": 103, 
         "target": 120, 
         "value": 1
      }, 
      {
         "source": 120, 
         "target": 121, 
         "value": 1
      }, 
      {
         "source": 120, 
         "target": 122, 
         "value": 1
      }, 
      {
         "source": 103, 
         "target": 123, 
         "value": 1
      }, 
      {
         "source": 123, 
         "target": 124, 
         "value": 1
      }, 
      {
         "source": 123, 
         "target": 125, 
         "value": 1
      }, 
      {
         "source": 103, 
         "target": 126, 
         "value": 1
      }, 
      {
         "source": 126, 
         "target": 127, 
         "value": 1
      }, 
      {
         "source": 126, 
         "target": 128, 
         "value": 1
      }, 
      {
         "source": 126, 
         "target": 129, 
         "value": 1
      }, 
      {
         "source": 126, 
         "target": 130, 
         "value": 1
      }, 
      {
         "source": 126, 
         "target": 131, 
         "value": 1
      }, 
      {
         "source": 103, 
         "target": 132, 
         "value": 1
      }, 
      {
         "source": 132, 
         "target": 133, 
         "value": 1
      }, 
      {
         "source": 132, 
         "target": 134, 
         "value": 1
      }, 
      {
         "source": 103, 
         "target": 135, 
         "value": 1
      }, 
      {
         "source": 135, 
         "target": 136, 
         "value": 1
      }, 
      {
         "source": 135, 
         "target": 137, 
         "value": 1
      }, 
      {
         "source": 66, 
         "target": 138, 
         "value": 1
      }, 
      {
         "source": 138, 
         "target": 139, 
         "value": 1
      }, 
      {
         "source": 139, 
         "target": 140, 
         "value": 1
      }, 
      {
         "source": 138, 
         "target": 141, 
         "value": 1
      }, 
      {
         "source": 141, 
         "target": 142, 
         "value": 1
      }, 
      {
         "source": 141, 
         "target": 143, 
         "value": 1
      }, 
      {
         "source": 141, 
         "target": 144, 
         "value": 1
      }, 
      {
         "source": 141, 
         "target": 145, 
         "value": 1
      }, 
      {
         "source": 66, 
         "target": 146, 
         "value": 1
      }, 
      {
         "source": 146, 
         "target": 147, 
         "value": 1
      }, 
      {
         "source": 147, 
         "target": 148, 
         "value": 1
      }, 
      {
         "source": 146, 
         "target": 149, 
         "value": 1
      }, 
      {
         "source": 149, 
         "target": 150, 
         "value": 1
      }, 
      {
         "source": 149, 
         "target": 151, 
         "value": 1
      }, 
      {
         "source": 149, 
         "target": 152, 
         "value": 1
      }, 
      {
         "source": 149, 
         "target": 153, 
         "value": 1
      }, 
      {
         "source": 149, 
         "target": 154, 
         "value": 1
      }, 
      {
         "source": 146, 
         "target": 155, 
         "value": 1
      }, 
      {
         "source": 155, 
         "target": 156, 
         "value": 1
      }, 
      {
         "source": 155, 
         "target": 157, 
         "value": 1
      }, 
      {
         "source": 146, 
         "target": 158, 
         "value": 1
      }, 
      {
         "source": 158, 
         "target": 159, 
         "value": 1
      }, 
      {
         "source": 158, 
         "target": 160, 
         "value": 1
      }, 
      {
         "source": 158, 
         "target": 161, 
         "value": 1
      }, 
      {
         "source": 158, 
         "target": 162, 
         "value": 1
      }, 
      {
         "source": 146, 
         "target": 163, 
         "value": 1
      }, 
      {
         "source": 163, 
         "target": 164, 
         "value": 1
      }, 
      {
         "source": 146, 
         "target": 165, 
         "value": 1
      }, 
      {
         "source": 165, 
         "target": 166, 
         "value": 1
      }, 
      {
         "source": 165, 
         "target": 167, 
         "value": 1
      }, 
      {
         "source": 165, 
         "target": 168, 
         "value": 1
      }, 
      {
         "source": 146, 
         "target": 169, 
         "value": 1
      }, 
      {
         "source": 169, 
         "target": 170, 
         "value": 1
      }, 
      {
         "source": 169, 
         "target": 171, 
         "value": 1
      }, 
      {
         "source": 169, 
         "target": 172, 
         "value": 1
      }, 
      {
         "source": 169, 
         "target": 173, 
         "value": 1
      }, 
      {
         "source": 169, 
         "target": 174, 
         "value": 1
      }, 
      {
         "source": 169, 
         "target": 175, 
         "value": 1
      }, 
      {
         "source": 169, 
         "target": 176, 
         "value": 1
      }, 
      {
         "source": 169, 
         "target": 177, 
         "value": 1
      }, 
      {
         "source": 169, 
         "target": 178, 
         "value": 1
      }, 
      {
         "source": 169, 
         "target": 179, 
         "value": 1
      }, 
      {
         "source": 169, 
         "target": 180, 
         "value": 1
      }, 
      {
         "source": 169, 
         "target": 181, 
         "value": 1
      }, 
      {
         "source": 169, 
         "target": 182, 
         "value": 1
      }, 
      {
         "source": 169, 
         "target": 183, 
         "value": 1
      }, 
      {
         "source": 169, 
         "target": 184, 
         "value": 1
      }, 
      {
         "source": 169, 
         "target": 185, 
         "value": 1
      }, 
      {
         "source": 169, 
         "target": 186, 
         "value": 1
      }, 
      {
         "source": 169, 
         "target": 187, 
         "value": 1
      }, 
      {
         "source": 146, 
         "target": 188, 
         "value": 1
      }, 
      {
         "source": 188, 
         "target": 189, 
         "value": 1
      }, 
      {
         "source": 188, 
         "target": 190, 
         "value": 1
      }
   ]
}
