var treeData = 

// {'name': 'mammals',
// 'value': 100,
// 'children': []}

{'name': 'mammals',
'value': 100,
'children': [

	{'name': 'carnivora',
	'value': 100,
	'children': [

		{'name': 'canids',
		'value': 100,
		'children': [

			{'name': 'dogs',
			'value': 100,
			'children': []},

			{'name': 'foxes',
			'value': 100,
			'children': []}

		]},

	{'name': 'kitties',
			'value': 100,
			'children': [

			{'name': 'lions',
			'value': 100,
			'children': []},

			{'name': 'tigers',
			'value': 100,
			'children': []},

			{'name': 'ocelots',
			'value': 100,
			'children': []},

			{'name': 'housecats?',
			'value': 100,
			'children': []},

			]},

		{'name': 'pinnipeds',
		'value': 100,
		'children': [

			{'name': 'sea lions',
			'value': 100,
			'children': []},
			
			{'name': 'seals',
			'value': 100,
			'children': [

				{'name': 'fur seal',
				'value': 100,
				'children': []},

				{'name': 'cute little baby seal',
				'value': 100,
				'children': []},

			]},

		]}


	]},

	{'name': 'cetaceans',
	'value': 100,
	'children': [

		{'name': 'odontocetes',
		'value': 100,
		'children': [

			{'name': 'dolphins',
				'value': 100,
				'children': []},

			{'name': 'orcas',
			'value': 100,
			'children': []},

			{'name': 'pilot whales',
				'value': 100,
				'children': []},


		]},


		{'name': 'other whales?',
		'value': 100,
		'children': [

			{'name': 'humpbacks',
				'value': 100,
				'children': []},

			{'name': 'blue whales',
			'value': 100,
			'children': []},

		]}


	]},


	{'name': 'bats!',
			'value': 100,
			'children': [

			{'name': 'micro ones',
			'value': 100,
			'children': [

				{'name': 'ugly bats',
				'value': 100,
				'children': []},

				{'name': 'cute bats',
				'value': 100,
				'children': []},
			]},

			{'name': 'macro ones?',
			'value': 100,
			'children': [

				{'name': 'flying foxes',
				'value': 100,
				'children': []},

				{'name': 'probably fruit bats?',
				'value': 100,
				'children': [

					{'name': 'apple bats',
					'value': 100,
					'children': []},

					{'name': 'orange bats',
					'value': 100,
					'children': [

						{'name': 'tangerine bats',
					'value': 100,
					'children': []},

					{'name': 'blood orange bats',
					'value': 100,
					'children': [

					{'name': 'type 0- blood orange bats',
					'value': 100,
					'children': []},

					{'name': 'type AB+ blood orange bats',
					'value': 100,
					'children': []},

					]},					


					]},

					{'name': 'banana bats',
					'value': 100,
					'children': []},

				]},

			]},

		]},


	{'name': 'elephants',
	'value': 100,
	'children': [

		{'name': 'regular elephants',
			'value': 100,
			'children': []},

		{'name': 'mammoths',
		'value': 100,
		'children': [


			{'name': 'woolly',
			'value': 100,
			'children': []},

			{'name': 'silky',
			'value': 100,
			'children': []},

		]},


	]},



	{'name': 'primates',
	'value': 100,
	'children': [

		{'name': 'humans',
		'value': 100,
		'children': []},

		{'name': 'chimps',
		'value': 100,
		'children': [

			{'name': 'bonobos',
			'value': 100,
			'children': []},

			{'name': 'pan troglodyes',
			'value': 100,
			'children': []}
		]},

		{'name': 'gorrillas',
		'value': 100,
		'children': []},

		{'name': 'orangs',
		'value': 100,
		'children': []}


	]},

	{'name': 'ungulates',
		'value': 100,
		'children': [

			{'name': 'llamas',
			'value': 100,
			'children': [

				{'name': 'big llamas',
				'value': 100,
				'children': []},

				{'name': 'little llamas',
				'value': 100,
				'children': []},
			]},

		{'name': 'unicorns',
		'value': 100,
		'children': []},

		{'name': 'rhinos',
		'value': 100,
		'children': [
			{'name': 'wooly rhinos',
			'value': 100,
			'children': []},
			{'name': 'black rhinos',
			'value': 100,
			'children': []},
			{'name': 'white rhinos',
			'value': 100,
			'children': []},
		]},

	]},


]}

