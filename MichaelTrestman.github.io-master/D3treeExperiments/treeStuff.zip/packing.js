var width = 1900;
var height = 1800;

var canvas = d3.select('body').append('svg')
	.attr('width', width)
	.attr('height', height)
	.append('g')
		.attr('transform', 'translate(50, 50)');


var pack = d3.layout.pack()
	.size([width, height - 50])
	.padding(10);



var nodes = pack.nodes(treeData);


var node = canvas.selectAll(".node")
	.data(nodes)
	.enter()
	.append('g')
		.attr("class", "node")
		.attr("transform", function (d) {return "translate(" + d.x + "," + d.y + ")";} );


node.append("circle")
	.attr("r", function(d) {return d.r;})
	.attr("fill", 
    function(d) { return "cyan"})
	.attr("opacity", 0.25)
	.attr("stroke", "#ADADAD")
	.attr("stroke-width", "2");


var diagonal = d3.svg.diagonal();

d3.selectAll('circle')
  
  .on('mouseover', function() {
  	d3.select(this)
  	.attr("fill", "yellow")
  })
  .on ('mouseout',  function() {
  	
  	console.log(this);
  	d3.select(this).attr("fill", "blue")

  });

  // d3.selectAll('.node')
  // 	.on('mouseover', function(){
  // 		d3.select(this)
  // 		.append("text").text(function(d) {return d.name })
  // 	}).attr("class", "bork")

  // 	// .on('mouseout', function(){
  		
  // 	// 	 d3.select(this).select("text")
  // 	// 	.text(function(d) {return " "})
  		

  // 	// })


  var tooltip = d3.select("body")
    .append("div")
    .style("position", "absolute")
    .style("z-index", "10")
    .style("visibility", "hidden")
    .style("color", "black")
    .style("font-size", "3em")
    .text("a simple tooltip");

    node
        .on("mouseover", function(d){

            if (d.children) {

              console.log(d.children.length); 
            } else { console.log(0)};

          
          tooltip.text(d.name);
          tooltip.style("visibility", "visible");
        })
        .on("mousemove", function(){return tooltip.style("top",
          (d3.event.pageY-200)+"px").style("left",(d3.event.pageX+10)+"px");})

        .on("mouseout", function(){return tooltip.style("visibility", "hidden");});







